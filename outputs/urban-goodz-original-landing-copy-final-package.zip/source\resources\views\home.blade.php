@extends('layouts.landing.app')
@php($business_name = \App\CentralLogics\Helpers::get_business_settings('business_name'))
@section('title', translate('messages.landing_page') . ' | ' . $business_name != 'null' ? $business_name : 'Urban Goodz')
@section('content')

    <!-- ============================================================
         HERO — Task 2: Urban Goodz Futuristic Hero
         ============================================================ -->
    <section class="hero">
        <div class="container">
            <div class="hero-badge">
                <span>&#9733;</span> Relaunching Soon
            </div>
            <h1>Your Connection To <span class="hl">Local Everything</span></h1>
            <p>Urban Goodz connects you to local products, services, rentals, events, creators, drivers, vendors, and business discovery through one powerful marketplace.</p>
            <div class="hero-btns">
                <a href="#" class="hero-btn hero-btn--primary hero-btn--primary">Explore Urban Goodz</a>
                <a href="{{ route('restaurant.create') }}" class="hero-btn hero-btn--outline">Become a Vendor</a>
                <a href="{{ route('deliveryman.create') }}" class="hero-btn hero-btn--outline">Earn With Urban Goodz</a>
            </div>
            <div class="hero-launch-line">
                <strong>Houston Starts It.</strong> Built For Everywhere.
            </div>
        </div>
        <div class="hero-illustration">
            @include('layouts.landing._hero-illustration')
        </div>
    </section>

    <!-- ============================================================
         LAUNCH NOTICE — Task 12: Preview / Launch Notice
         ============================================================ -->
    <section class="launch-notice launch-notice--dijon">
        <div class="container">
            <p>Urban Goodz is relaunching in phases. Some features are in <strong>preview</strong> or <strong>test mode</strong> while the upgraded platform activates across our market network.</p>
        </div>
    </section>

    <!-- ============================================================
         MARKETPLACE CATEGORY GRID — Everything Local. One Marketplace.
         Real-image cards using original landing assets
         ============================================================ -->
    <section class="ug-section ug-section--light">
        <div class="container">
            <div class="sec-header">
                <h2>Everything Local. One Marketplace.</h2>
                <p>One platform, endless local possibilities</p>
            </div>
            <div class="ug-cards-grid ug-cards-grid--10">
                <div class="ug-card">
                    <div class="card-icon"><img src="{{ asset('/public/assets/landing/img/feature/shopping.svg') }}" alt="Retail & Shopping" /></div>
                    <h4>Retail &amp; Shopping</h4>
                    <p>Shop local stores, browse products, order for pickup or delivery</p>
                </div>
                <div class="ug-card">
                    <div class="card-icon"><img src="{{ asset('/public/assets/landing/img/category/main-category-1.png') }}" alt="Beauty Supply" /></div>
                    <h4>Beauty Supply / Hair Providerz</h4>
                    <p>Book appointments, shop products, find local stylists</p>
                </div>
                <div class="ug-card">
                    <div class="card-icon"><img src="{{ asset('/public/assets/landing/img/category/grocery.svg') }}" alt="Food & Grocery" /></div>
                    <h4>Food &amp; Grocery</h4>
                    <p>Order meals and groceries from nearby restaurants and markets</p>
                </div>
                <div class="ug-card">
                    <div class="card-icon"><img src="{{ asset('/public/assets/landing/img/venture/venture1.png') }}" alt="Rentals" /></div>
                    <h4>Rentals</h4>
                    <p>Rent tools, equipment, event items, and more from neighbors</p>
                </div>
                <div class="ug-card">
                    <div class="card-icon"><img src="{{ asset('/public/assets/landing/img/feature/location.svg') }}" alt="Services" /></div>
                    <h4>Services</h4>
                    <p>Find local pros for repairs, cleaning, tutoring, and more</p>
                </div>
                <div class="ug-card">
                    <div class="card-icon"><img src="{{ asset('/public/assets/landing/img/feature/trusted.svg') }}" alt="Events & Creators" /></div>
                    <h4>Events &amp; Creators</h4>
                    <p>Discover local events, support creators, book talent</p>
                </div>
                <div class="ug-card">
                    <div class="card-icon"><img src="{{ asset('/public/assets/landing/img/feature/delivery.svg') }}" alt="Courier & Delivery" /></div>
                    <h4>Courier &amp; Delivery</h4>
                    <p>Send packages across town with fast, tracked delivery</p>
                </div>
                <div class="ug-card">
                    <div class="card-icon"><img src="{{ asset('/public/assets/landing/img/category/main-category-2.png') }}" alt="Fashion / Tailoring" /></div>
                    <h4>Fashion / Tailoring</h4>
                    <p>Manual measurements, alterations, seamstress &amp; tailor services</p>
                </div>
                <div class="ug-card">
                    <div class="card-icon"><img src="{{ asset('/public/assets/landing/img/feature/payment.svg') }}" alt="Order Anywhere" /></div>
                    <h4>Order Anywhere</h4>
                    <p>Request items from local businesses not yet onboarded</p>
                </div>
                <div class="ug-card">
                    <div class="card-icon"><img src="{{ asset('/public/assets/landing/img/earn-money/earn-money-1.png') }}" alt="Earn Money" /></div>
                    <h4>Earn Money</h4>
                    <p>Deliver, rent items, offer services &mdash; earn on your terms</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================
         ASK URBAN GOODZ — Task 3: AI-Guided Search / Concierge
         Example prompt chips, preview label, no false AI claims
         ============================================================ -->
    <section class="ug-section ug-section--white">
        <div class="container">
            <div class="sec-header">
                <span class="sec-preview-badge">AI-guided discovery preview</span>
                <h2>Ask Urban Goodz</h2>
                <p>Tell Urban Goodz what you need. Search for products, services, rentals, events, businesses, opportunities, and local providers in one place.</p>
            </div>
            <div class="ug-ask-grid">
                <div class="ug-ask-chips">
                    <button class="ug-chip" type="button">Need braiding hair</button>
                    <button class="ug-chip" type="button">Rent a pickup truck</button>
                    <button class="ug-chip" type="button">Find a barber</button>
                    <button class="ug-chip" type="button">Book a photographer</button>
                    <button class="ug-chip" type="button">Need a courier</button>
                    <button class="ug-chip" type="button">Find local events</button>
                    <button class="ug-chip" type="button">Order from a store nearby</button>
                    <button class="ug-chip" type="button">Find Black-owned businesses</button>
                </div>
                <div class="ug-ask-search">
                    <div class="ug-search-bar">
                        <span class="ug-search-icon">&#x1F50D;</span>
                        <input type="text" placeholder="Ask Urban Goodz anything..." readonly />
                        <span class="ug-search-hint">AI-guided discovery preview</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ============================================================
         ORDER ANYWHERE — Task 5: Order Anywhere Section
         Preview status, no false claims about live dispatch/payment
         ============================================================ -->
    <section class="ug-section ug-section--canvas">
        <div class="container">
            <div class="ug-single-section">
                <div class="ug-single-icon"><img src="{{ asset('/public/assets/landing/img/feature/payment.svg') }}" alt="Order Anywhere" style="width:44px;height:44px;object-fit:contain;filter:brightness(0) invert(0)" /></div>
                <h2>Order Anywhere</h2>
                <p class="ug-single-copy">Need something from a local business that is not fully onboarded yet? Submit a request and Urban Goodz helps turn local demand into fulfillment.</p>
                <div class="ug-status-box">
                    <span class="status-badge status-badge--preview">Preview</span>
                    <p>Order Anywhere is entering test mode. Live payment, dispatch, and reconciliation are being completed before production launch.</p>
                </div>
                <a href="#" class="ug-cta-btn">Preview Order Anywhere &#8594;</a>
            </div>
        </div>
    </section>

    <!-- ============================================================
         RENTALS — Task 6: Rent What You Need
         Most complete vertical, shown as tester-ready
         ============================================================ -->
    <section class="ug-section ug-section--light">
        <div class="container">
            <div class="ug-single-section">
                <div class="ug-single-icon"><img src="{{ asset('/public/assets/landing/img/venture/venture1.png') }}" alt="Rentals" style="width:48px;height:auto;object-fit:contain" /></div>
                <h2>Rent What You Need</h2>
                <p class="ug-single-copy">From vehicles to equipment and local rental needs, Urban Goodz brings rentals into the same marketplace where people already shop, book, and discover.</p>
                <div class="ug-status-box">
                    <span class="status-badge status-badge--live">Available (Tester)</span>
                    <p>Rentals is our most complete new vertical &mdash; available now in the tester app.</p>
                </div>
                <a href="https://test.urbangoodzdelivery.com" target="_blank" class="ug-cta-btn">Explore Rentals &#8594;</a>
            </div>
        </div>
    </section>

    <!-- ============================================================
         SERVICES / FASHION / TAILORING — Task 7: Book Local Services
         Fashion/tailoring with measurement tools in development
         ============================================================ -->
    <section class="ug-section ug-section--dijon">
        <div class="container">
            <div class="ug-single-section">
                <div class="ug-single-icon">&#x1F4CB;</div>
                <h2>Book Local Services</h2>
                <p class="ug-single-copy">Find local service providers for beauty, grooming, professional services, home help, creative work, fashion, tailoring, alterations, and custom fit needs.</p>
                <div class="ug-two-col">
                    <div class="ug-mini-card">
                        <h4>Fashion / Tailoring</h4>
                        <p>Manual measurements, neck-to-floor measurements, photo-assisted previews, and seamstress/tailor verification are part of the Urban Goodz fashion direction.</p>
                        <span class="status-badge status-badge--preview">Fashion tools in development</span>
                    </div>
                    <div class="ug-mini-card">
                        <h4>Creative &amp; Professional</h4>
                        <p>Photographers, musicians, tutors, repair techs, cleaners, personal trainers &mdash; book local pros who serve your area.</p>
                        <span class="status-badge status-badge--preview">Coming Soon</span>
                    </div>
                </div>
                <a href="#" class="ug-cta-btn">Find Local Services &#8594;</a>
            </div>
        </div>
    </section>

    <!-- ============================================================
         EARN MONEY — Task 8: Earn With Urban Goodz
         Earning path cards: Delivery, Courier, Order Anywhere pickups,
         Rental support, Creator campaigns, Vendor referrals, Load board
         ============================================================ -->
    <section class="ug-section ug-section--light">
        <div class="container">
            <div class="sec-header">
                <h2>Earn With Urban Goodz</h2>
                <p>Urban Goodz creates earning paths for delivery drivers, couriers, rental partners, service providers, creators, vendors, and future logistics opportunities.</p>
            </div>
            <div class="ug-earn-grid">
                <div class="ug-earn-card">
                    <div class="ug-earn-num">1</div>
                    <h4>Delivery</h4>
                    <p>Deliver orders from local businesses on your schedule.</p>
                </div>
                <div class="ug-earn-card">
                    <div class="ug-earn-num">2</div>
                    <h4>Courier</h4>
                    <p>Send and earn by transporting packages across town.</p>
                </div>
                <div class="ug-earn-card">
                    <div class="ug-earn-num">3</div>
                    <h4>Order Anywhere Pickups</h4>
                    <p>Fulfill requests from customers who need items picked up.</p>
                </div>
                <div class="ug-earn-card">
                    <div class="ug-earn-num">4</div>
                    <h4>Rental Support</h4>
                    <p>Facilitate rental transactions and earn from each booking.</p>
                </div>
                <div class="ug-earn-card">
                    <div class="ug-earn-num">5</div>
                    <h4>Creator Campaigns</h4>
                    <p>Promote local businesses and earn through referral campaigns.</p>
                </div>
                <div class="ug-earn-card">
                    <div class="ug-earn-num">6</div>
                    <h4>Vendor Referrals</h4>
                    <p>Refer merchants and earn when they join Urban Goodz.</p>
                </div>
                <div class="ug-earn-card">
                    <div class="ug-earn-num">7</div>
                    <h4>Load Board <span class="lbl-sm">(Future)</span></h4>
                    <p>Future logistics and bulk transport earning opportunities.</p>
                </div>
            </div>
            <div class="ug-earn-cta">
                <a href="{{ route('deliveryman.create') }}" class="ug-cta-btn">Start Earning &#8594;</a>
            </div>
        </div>
    </section>

    <!-- ============================================================
         BUSINESS DISCOVERY — Task 9: Business Discovery Engine
         ============================================================ -->
    <section class="ug-section ug-section--light">
        <div class="container">
            <div class="ug-single-section">
                <div class="ug-single-icon"><img src="{{ asset('/public/assets/landing/img/feature/location.svg') }}" alt="Business Discovery" style="width:44px;height:44px;object-fit:contain" /></div>
                <h2>Business Discovery Engine</h2>
                <p class="ug-single-copy">Urban Goodz turns searches, requests, and unmet demand into business discovery, merchant leads, and new local opportunities.</p>
                <p class="ug-single-sub">When customers search and cannot find what they need, Urban Goodz can capture that demand and help bring businesses into the marketplace.</p>
                <a href="{{ route('restaurant.create') }}" class="ug-cta-btn">List Your Business &#8594;</a>
            </div>
        </div>
    </section>

    <!-- ============================================================
         HOUSTON LAUNCH — Houston Starts It. Built For Everywhere.
         ============================================================ -->
    <section class="ug-section ug-section--canvas">
        <div class="container">
            <div class="ug-houston-section">
                <div class="ug-houston-icon"><img src="{{ asset('/public/assets/landing/img/logo.svg') }}" alt="Urban Goodz" style="width:48px;height:auto;object-fit:contain" /></div>
                <h2>Houston Starts It. Built For Everywhere.</h2>
                <p>Urban Goodz is relaunching with an expanded platform built to connect communities to more than delivery. Houston is the current live relaunch hub.</p>
                <div class="ug-houston-line">
                    <strong>Built in Houston. Designed for everywhere.</strong>
                </div>
                <div class="ug-houston-tagline">One Platform. Unlimited Possibilities.</div>
            </div>
        </div>
    </section>

    <!-- ============================================================
         ROLE-BASED CTA — Task 11: Customer / Vendor / Driver CTA Cards
         ============================================================ -->
    <section class="ug-section ug-section--canvas">
        <div class="container">
            <div class="sec-header">
                <h2>Join The Urban Goodz Community</h2>
                <p>Whether you shop, sell, or serve &mdash; there's a place for you</p>
            </div>
            <div class="ug-cta-grid">
                <div class="ug-cta-card">
                    <div class="cta-emoji"><img src="{{ asset('/public/assets/landing/img/feature/shopping.svg') }}" alt="Customers" style="width:36px;height:36px;object-fit:contain;filter:brightness(0) invert(0)" /></div>
                    <h3>For Customers</h3>
                    <p>Find it. Book it. Rent it. Get it. Everything local in one marketplace.</p>
                    <a href="https://test.urbangoodzdelivery.com" target="_blank" class="ug-cta-btn">Explore the Marketplace &#8594;</a>
                </div>
                <div class="ug-cta-card">
                    <div class="cta-emoji"><img src="{{ asset('/public/assets/landing/img/feature/payment.svg') }}" alt="Vendors" style="width:36px;height:36px;object-fit:contain;filter:brightness(0) invert(0)" /></div>
                    <h3>For Vendors</h3>
                    <p>Get discovered, receive demand, and grow your business. List your store or service today.</p>
                    <a href="https://admin.urbangoodzdelivery.com/login/vendor" target="_blank" class="ug-cta-btn">Join as Vendor &#8594;</a>
                </div>
                <div class="ug-cta-card">
                    <div class="cta-emoji"><img src="{{ asset('/public/assets/landing/img/feature/delivery.svg') }}" alt="Drivers" style="width:36px;height:36px;object-fit:contain;filter:brightness(0) invert(0)" /></div>
                    <h3>For Drivers / Partners</h3>
                    <p>Earn through deliveries, pickups, courier work, rentals, and future logistics opportunities.</p>
                    <a href="{{ route('deliveryman.create') }}" class="ug-cta-btn ug-cta-btn--outline">Join as Delivery Partner &#8594;</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Services -->
    @php($modules = \App\Models\Module::Active()->get())
    @if($modules && count($modules) > 0)
    <section class="services-section">
        <div class="container">
            <div class="sec-header">
                <h2>{!! \App\CentralLogics\Helpers::highlight($landing_data['fixed_module_title']) !!}</h2>
                <p>{!! \App\CentralLogics\Helpers::highlight($landing_data['fixed_module_sub_title']) !!}</p>
            </div>
            <div class="slider-wrap svc-slider-wrap">
                <div class="svc-icons">
                    @foreach ($modules as $key => $item)
                    <button class="svc-icon-btn {{ $key == 0 ? 'active' : '' }}" data-svc="svc-{{ $key }}">
                        <span class="ico"><img class="onerror-image" data-onerror-image="{{ asset('public/assets/admin/img/100x100/2.png') }}" src="{{ $item['icon_full_url'] ?? asset('public/assets/admin/img/100x100/2.png') }}" alt="{{ $item->module_name }}" /></span>
                        <span class="lbl">{{ translate("messages.{$item->module_name}") }}</span>
                    </button>
                    @endforeach
                </div>
                <div class="slider-nav">
                    <button class="slider-arrow slider-prev" data-target=".svc-icons">&#8592;</button>
                    <button class="slider-arrow slider-next" data-target=".svc-icons">&#8594;</button>
                </div>
            </div>
            <div class="svc-panels">
                @foreach ($modules as $key => $item)
                <div class="svc-panel {{ $key == 0 ? 'active' : '' }}" data-panel="svc-{{ $key }}">
                    <div class="svc-text">
                        <div class="venture-content-box">
                            {!! $item->description ?? '' !!}
                        </div>
                    </div>
                    <div class="svc-img">
                        <div class="img-card">
                            <img src="{{ $item['thumbnail_full_url'] ?? asset('public/assets/admin/img/100x100/2.png') }}" class="onerror-image" data-onerror-image="{{ asset('public/assets/admin/img/100x100/2.png') }}" alt="{{ $item->module_name }}" />
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            <div class="svc-nav">
                <button class="svc-arrow" id="svcPrev">&#8592;</button>
                <button class="svc-arrow" id="svcNext">&#8594;</button>
            </div>
        </div>
    </section>
    @endif

    <!-- Marquee -->
    @php($promo_banners = $landing_data['promotional_banners'])
    @if(isset($promo_banners) && count($promo_banners) > 0)
    <section class="marquee">
        <div class="marquee-track">
            @foreach ($promo_banners as $item)
            <span class="mq-item"><span class="dot"></span><span class="find">{{ $item['title'] ?? '' }}</span> {{ $item['sub_title'] ?? '' }}</span>
            @endforeach
            @foreach ($promo_banners as $item)
            <span class="mq-item"><span class="dot"></span><span class="find">{{ $item['title'] ?? '' }}</span> {{ $item['sub_title'] ?? '' }}</span>
            @endforeach
        </div>
    </section>
    @endif

    <!-- Features -->
    @php($feature = $landing_data['features'])
    @if (isset($feature) && count($feature) > 0)
    <section class="features">
        <div class="container">
            <div class="sec-header">
                <h2>{!! \App\CentralLogics\Helpers::highlight($landing_data['feature_title']) !!}</h2>
                <p>{!! \App\CentralLogics\Helpers::highlight($landing_data['feature_short_description']) !!}</p>
            </div>
            <div class="slider-wrap">
                <div class="feat-grid">
                    @foreach ($feature as $item)
                    <div class="feat-card">
                        <span class="feat-ico"><img src="{{ $item['image_full_url'] }}" alt="{{ $item['title'] ?? '' }}" /></span>
                        <h4>{{ $item['title'] ?? '' }}</h4>
                        <p>{{ $item['sub_title'] ?? '' }}</p>
                    </div>
                    @endforeach
                </div>
                <div class="slider-nav">
                    <button class="slider-arrow slider-prev" data-target=".feat-grid">&#8592;</button>
                    <button class="slider-arrow slider-next" data-target=".feat-grid">&#8594;</button>
                </div>
            </div>
        </div>
    </section>
    @endif

    <!-- Zones -->
    @if ($landing_data['available_zone_status'] && $landing_data['available_zone_list'])
    <section class="zones">
        <div class="container">
            <div class="zone-banner">
                <div class="zone-img-side">
                    <img src="{{ $landing_data['available_zone_image_full_url'] }}" alt="Delivery Zone Map" />
                </div>
                <div class="zone-text-side">
                    <h2>{!! \App\CentralLogics\Helpers::highlight($landing_data['available_zone_title']) !!}</h2>
                    <p>{!! \App\CentralLogics\Helpers::highlight($landing_data['available_zone_short_description']) !!}</p>
                    <div class="zone-tags">
                        @foreach ($landing_data['available_zone_list'] as $zone)
                            @if (count($zone['modules']->toArray()) > 0)
                            <div class="zone-tag" data-toggle="tooltip" data-placement="top" title="{{ count($zone['modules']->toArray()) > 0 ? implode(', ', $zone['modules']->toArray()) . ' ' . translate('are_available.') : translate('right_now_no_module_available.') }}"><span class="zone-dot"></span> {{ $zone['display_name'] }}</div>
                            @endif
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </section>
    @endif

    <!-- Referral -->
    <section class="referral">
        <div class="container">
            <div class="refer-card">
                <div><h2>{!! \App\CentralLogics\Helpers::highlight($landing_data['fixed_referal_title']) !!}</h2></div>
            </div>
        </div>
    </section>

    <!-- Earn -->
    <section class="earn">
        <div class="container">
            <div class="earn-top">
                <h2>{!! \App\CentralLogics\Helpers::highlight($landing_data['earning_title']) !!}</h2>
                <p>Shop, rent, discover events, support local businesses, and access services all from one app.</p>
            </div>
            <div class="slider-wrap">
            <div class="earn-grid">
                <!-- Seller Card -->
                <div class="earn-card">
                    @if(!empty($landing_data['seller_card_image']))
                        <div class="earn-card-icon"><img src="{{ $landing_data['seller_card_image'] }}" alt="" style="width:44px;height:44px;object-fit:contain"></div>
                    @else
                        <div class="earn-card-icon">&#x1F3EA;</div>
                    @endif
                    <h3>{!! \App\CentralLogics\Helpers::highlight($landing_data['seller_card_title'] ?? translate('messages.Become a best') . ' $' . translate('messages.Seller') . '$') !!}</h3>
                    <p>{!! \App\CentralLogics\Helpers::highlight($landing_data['seller_card_subtitle'] ?? translate('Grow your business with us. Reach thousands of customers and manage orders effortlessly.')) !!}</p>
                    @php($join_as_seller = $landing_data['seller_app_earning_links'])
                    <div class="earn-app-row">
                        @if (isset($join_as_seller['playstore_url_status']) && $join_as_seller['playstore_url_status'] == '1')
                        <a href="{{ isset($join_as_seller['playstore_url']) ? $join_as_seller['playstore_url'] : '' }}" class="app-btn">
                            <img src="{{ asset('/public/assets/landing/img/google-play.png') }}" alt="Google Play" />
                            <span class="ab-text"><span class="ab-sm">{{ translate('Get it on') }}</span><span class="ab-lg">{{ translate('Google Play') }}</span></span>
                        </a>
                        @endif
                        @if (isset($join_as_seller['apple_store_url_status']) && $join_as_seller['apple_store_url_status'] == '1')
                        <a href="{{ isset($join_as_seller['apple_store_url']) ? $join_as_seller['apple_store_url'] : '' }}" class="app-btn">
                            <img src="{{ asset('/public/assets/landing/img/apple-store.png') }}" alt="App Store" />
                            <span class="ab-text"><span class="ab-sm">{{ translate('Download on the') }}</span><span class="ab-lg">{{ translate('App Store') }}</span></span>
                        </a>
                        @endif
                    </div>
                </div>
                <!-- Deliveryman Card -->
                <div class="earn-card">
                    @if(!empty($landing_data['dm_card_image']))
                        <div class="earn-card-icon"><img src="{{ $landing_data['dm_card_image'] }}" alt="" style="width:44px;height:44px;object-fit:contain"></div>
                    @else
                        <div class="earn-card-icon">&#x1F6F5;</div>
                    @endif
                    <h3>{!! \App\CentralLogics\Helpers::highlight($landing_data['dm_card_title'] ?? translate('messages.Become a smart') . ' $' . translate('messages.Deliveryman') . '$') !!}</h3>
                    <p>{!! \App\CentralLogics\Helpers::highlight($landing_data['dm_card_subtitle'] ?? translate('Deliver on your own schedule. Earn competitive pay with flexible hours and easy-to-use tools.')) !!}</p>
                    @php($join_as_dm = $landing_data['dm_app_earning_links'])
                    <div class="earn-app-row">
                        @if (isset($join_as_dm['playstore_url_status']) && $join_as_dm['playstore_url_status'] == '1')
                        <a href="{{ isset($join_as_dm['playstore_url']) ? $join_as_dm['playstore_url'] : '' }}" class="app-btn">
                            <img src="{{ asset('/public/assets/landing/img/google-play.png') }}" alt="Google Play" />
                            <span class="ab-text"><span class="ab-sm">{{ translate('Get it on') }}</span><span class="ab-lg">{{ translate('Google Play') }}</span></span>
                        </a>
                        @endif
                        @if (isset($join_as_dm['apple_store_url_status']) && $join_as_dm['apple_store_url_status'] == '1')
                        <a href="{{ isset($join_as_dm['apple_store_url']) ? $join_as_dm['apple_store_url'] : '' }}" class="app-btn">
                            <img src="{{ asset('/public/assets/landing/img/apple-store.png') }}" alt="App Store" />
                            <span class="ab-text"><span class="ab-sm">{{ translate('Download on the') }}</span><span class="ab-lg">{{ translate('App Store') }}</span></span>
                        </a>
                        @endif
                    </div>
                </div>

                <!-- Rider Card -->
                @if(addon_published_status('RideShare'))
                <div class="earn-card">
                    @if(!empty($landing_data['rider_card_image']))
                        <div class="earn-card-icon"><img src="{{ $landing_data['rider_card_image'] }}" alt="" style="width:44px;height:44px;object-fit:contain"></div>
                    @else
                        <div class="earn-card-icon">&#x1F697;</div>
                    @endif
                    <h3>{!! \App\CentralLogics\Helpers::highlight($landing_data['rider_card_title'] ?? translate('messages.Become a smart') . ' $' . translate('messages.Rider') . '$') !!}</h3>
                    <p>{!! \App\CentralLogics\Helpers::highlight($landing_data['rider_card_subtitle'] ?? translate('Drive and earn on your own terms. Flexible rides, great pay, and easy-to-use tools.')) !!}</p>
                    @php($join_as_rider = $landing_data['rider_app_earning_links'])
                    <div class="earn-app-row">
                        @if (isset($join_as_rider['playstore_url_status']) && $join_as_rider['playstore_url_status'] == '1')
                        <a href="{{ isset($join_as_rider['playstore_url']) ? $join_as_rider['playstore_url'] : '' }}" class="app-btn">
                            <img src="{{ asset('/public/assets/landing/img/google-play.png') }}" alt="Google Play" />
                            <span class="ab-text"><span class="ab-sm">{{ translate('Get it on') }}</span><span class="ab-lg">{{ translate('Google Play') }}</span></span>
                        </a>
                        @endif
                        @if (isset($join_as_rider['apple_store_url_status']) && $join_as_rider['apple_store_url_status'] == '1')
                        <a href="{{ isset($join_as_rider['apple_store_url']) ? $join_as_rider['apple_store_url'] : '' }}" class="app-btn">
                            <img src="{{ asset('/public/assets/landing/img/apple-store.png') }}" alt="App Store" />
                            <span class="ab-text"><span class="ab-sm">{{ translate('Download on the') }}</span><span class="ab-lg">{{ translate('App Store') }}</span></span>
                        </a>
                        @endif
                    </div>
                </div>
                @endif
            </div>
                <div class="slider-nav">
                    <button class="slider-arrow slider-prev" data-target=".earn-grid">&#8592;</button>
                    <button class="slider-arrow slider-next" data-target=".earn-grid">&#8594;</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Special -->
    @php($special = $landing_data['criterias'])
    @if ($special && count($special) > 0)
    <section class="special">
        <div class="container"><div class="sec-header"><h2>{!! \App\CentralLogics\Helpers::highlight($landing_data['why_choose_title']) !!}</h2></div></div>
        <div class="sp-track">
            @foreach ($special as $item)
                @if ($item->status == '1')
                <div class="sp-card">
                    <span class="sp-ico"><img src="{{ $item['image_full_url'] }}" alt="{{ $item['title'] }}" class="onerror-image" data-onerror-image="{{ asset('public/assets/admin/img/160x160/img2.jpg') }}" /></span>
                    <h4>{{ $item['title'] }}</h4>
                    <p>{{ $item['sub_title'] ?? '' }}</p>
                </div>
                @endif
            @endforeach
        </div>
        <div class="sp-dots"></div>
    </section>
    @endif

    <!-- Stats -->
    @php($counter = $landing_data['counter_section'])
    @if (isset($counter) && $counter['status'] == '1')
    <section class="stats">
        <div class="container">
            <div class="slider-wrap">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    </div>
                    <div class="stat-num" data-t="{{ $counter['app_download_count_numbers'] ?? 0 }}">0<span class="plus">+</span></div>
                    <div class="stat-label">{{ translate('messages.Download') }}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
                    </div>
                    <div class="stat-num" data-t="{{ $counter['seller_count_numbers'] ?? 0 }}">0<span class="plus">+</span></div>
                    <div class="stat-label">{{ translate('messages.Seller') }}</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
                    </div>
                    <div class="stat-num" data-t="{{ $counter['deliveryman_count_numbers'] ?? 0 }}">0<span class="plus">+</span></div>
                    <div class="stat-label">{{ translate('messages.Deliveryman') }}</div>
                </div>
                @if(addon_published_status('RideShare'))
                <div class="stat-card">
                    <div class="stat-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
                    </div>
                    <div class="stat-num" data-t="{{ $counter['rider_count_numbers'] ?? 0 }}">0<span class="plus">+</span></div>
                    <div class="stat-label">{{ translate('messages.Rider') }}</div>
                </div>
                @endif
                <div class="stat-card">
                    <div class="stat-icon">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
                    </div>
                    <div class="stat-num" data-t="{{ $counter['customer_count_numbers'] ?? 0 }}">0<span class="plus">+</span></div>
                    <div class="stat-label">{{ translate('messages.customer') }}</div>
                </div>
            </div>
                <div class="slider-nav">
                    <button class="slider-arrow slider-prev" data-target=".stats-grid">&#8592;</button>
                    <button class="slider-arrow slider-next" data-target=".stats-grid">&#8594;</button>
                </div>
            </div>
            <div class="stats-note">{{ translate('messages.Still increasing') }}</div>
        </div>
    </section>
    @endif

    <!-- CTA / Download App -->
    @php($landing_page_links = $landing_data['download_user_app_links'])
    @if (
        (isset($landing_page_links['playstore_url_status']) && $landing_page_links['playstore_url_status'] == '1') ||
            (isset($landing_page_links['apple_store_url_status']) && $landing_page_links['apple_store_url_status'] == '1'))
    <section class="cta-manage">
        <div class="container">
            <div class="cta-box">
                <div class="cta-info">
                    <h2>Manage, Sell, and Earn With Urban Goodz</h2>
                    <button class="cta-user-btn">{{ translate('User App') }}</button>
                    <div class="cta-app-row">
                        @if (isset($landing_page_links['playstore_url_status']) && $landing_page_links['playstore_url_status'] == '1')
                        <a href="{{ $landing_page_links['playstore_url'] }}" class="cta-app-link">
                            <img src="{{ asset('/public/assets/landing/img/google-play.png') }}" alt="Google Play" style="filter:brightness(10)" />
                            <span class="cal-text"><span class="cal-sm">{{ translate('Get it on') }}</span><span class="cal-lg">{{ translate('Google Play') }}</span></span>
                        </a>
                        @endif
                        @if (isset($landing_page_links['apple_store_url_status']) && $landing_page_links['apple_store_url_status'] == '1')
                        <a href="{{ $landing_page_links['apple_store_url'] }}" class="cta-app-link">
                            <img src="{{ asset('/public/assets/landing/img/apple-store.png') }}" alt="Apple Store" style="filter:brightness(10)" />
                            <span class="cal-text"><span class="cal-sm">{{ translate('Download on the') }}</span><span class="cal-lg">{{ translate('Apple Store') }}</span></span>
                        </a>
                        @endif
                    </div>
                </div>
                <div class="cta-visual">
                    <div class="cta-phone">
                        <img src="{{ \App\CentralLogics\Helpers::get_full_url('download_user_app_image', isset($landing_data['download_user_app_image']) ? $landing_data['download_user_app_image'] : null, isset($landing_data['download_user_app_image_storage']) ? $landing_data['download_user_app_image_storage'] : 'public') }}" alt="User App" />
                    </div>
                </div>
            </div>
        </div>
    </section>
    @endif

    <!-- Testimonials -->
    @php($testimonial = $landing_data['testimonials'])
    @if ($testimonial && count($testimonial) > 0)
    <section class="testimonials">
        <div class="container">
            <div class="sec-header"><h2>{!! \App\CentralLogics\Helpers::highlight($landing_data['testimonial_title']) !!}</h2></div>
            <div class="slider-wrap">
                <div class="test-grid">
                    @foreach ($testimonial as $data)
                    <div class="test-card">
                        <div class="qm">&ldquo;</div>
                        <div class="test-stars">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                        <p class="test-text">{{ $data['review'] }}</p>
                        <div class="test-author">
                            <div class="test-av"><img src="{{ $data['reviewer_image_full_url'] }}" alt="{{ $data['name'] }}" /></div>
                            <div>
                                <div class="test-name">{{ $data['name'] }}</div>
                                <div class="test-role">{{ $data['designation'] }}</div>
                                @if (isset($data['company_image']))
                                <div class="test-company"><img src="{{ $data['company_image_full_url'] }}" alt="" /></div>
                                @endif
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                <div class="slider-nav">
                    <button class="slider-arrow slider-prev" data-target=".test-grid">&#8592;</button>
                    <button class="slider-arrow slider-next" data-target=".test-grid">&#8594;</button>
                </div>
            </div>
        </div>
    </section>
    @endif

    <!-- ============================================================
         MARKET NETWORK — Relaunching Across Our Market Network
         ============================================================ -->
    <section class="ug-section ug-section--white">
        <div class="container">
            <div class="ug-mkt-network">
                <div class="ug-mkt-icon"><img src="{{ asset('/public/assets/landing/img/logo.svg') }}" alt="Urban Goodz" style="width:48px;height:auto;object-fit:contain" /></div>
                <h2>Relaunching Across Our Market Network</h2>
                <p>Urban Goodz is relaunching with an expanded marketplace built to connect communities to local products, services, rentals, events, vendors, drivers, and business discovery.</p>
                <p>Houston is the current live relaunch hub as Urban Goodz activates its upgraded platform across its market network.</p>
                <p>As we activate the upgraded platform city by city, Urban Goodz will continue connecting customers, vendors, drivers, service providers, creators, and local businesses through one ecosystem.</p>
                <div class="ug-mkt-hubs">
                    <div class="ug-mkt-hub">
                        <span class="ug-mkt-label">Current Live Relaunch Hub:</span>
                        <span class="ug-mkt-value">Houston, Texas</span>
                    </div>
                    <div class="ug-mkt-hub">
                        <span class="ug-mkt-label">Urban Goodz Positioned Markets:</span>
                        <span class="ug-mkt-value">Texas, Alabama, Georgia, Florida, California, Nevada, Tennessee, North Carolina, Maryland, Washington D.C., Oklahoma, and more.</span>
                    </div>
                </div>
                <a href="#" class="ug-cta-btn">Request Full Activation In Your City &#8594;</a>
            </div>
        </div>
    </section>

    @if (isset($new_user) && $new_user == true)
    <div class="modal fade show" id="welcome-modal">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content border-0">
                <div class="modal-header border-0 pt-4 px-4">
                    <button type="button" class="btn-close shadow-none" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body px-sm-5 pb-5">
                    <div class="text-center">
                        <img src="{{ asset('/public/assets/landing/img/welcome.svg') }}" class="mw-100 mb-3 mx-auto d-block" alt="">
                        <h5 class="mb-3">{{ translate('Welcome_to') }} {{ $business_name }}!</h5>
                        <p class="m-0 mb-4">{{ translate('Thanks for joining us! Your registration is under review. Hang tight, we\'ll notify you once approved!') }}</p>
                        <button type="button" class="border-0 outline-0 shadow-none btn rounded-pill px-4" style="background:var(--green);color:#fff" data-bs-dismiss="modal">{{ translate('okay') }}</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @endif

@endsection
@push('script_2')
<script>
    "use strict";
    // Service tabs + prev/next
    const svcBtns=document.querySelectorAll('.svc-icon-btn'),svcPanels=document.querySelectorAll('.svc-panel');
    let svcIdx=0;
    function showSvc(i){svcIdx=i;svcBtns.forEach(b=>b.classList.remove('active'));svcPanels.forEach(p=>p.classList.remove('active'));if(svcBtns[i])svcBtns[i].classList.add('active');if(svcPanels[i])svcPanels[i].classList.add('active');if(svcBtns[i])svcBtns[i].scrollIntoView({behavior:'smooth',block:'nearest',inline:'center'})}
    svcBtns.forEach((b,i)=>b.addEventListener('click',()=>showSvc(i)));
    const svcCount=svcBtns.length;
    const prevBtn=document.getElementById('svcPrev');
    const nextBtn=document.getElementById('svcNext');
    if(prevBtn)prevBtn.addEventListener('click',()=>showSvc((svcIdx-1+svcCount)%svcCount));
    if(nextBtn)nextBtn.addEventListener('click',()=>showSvc((svcIdx+1)%svcCount));

    // Stats counter with IntersectionObserver
    function formatStatNum(n){
        if(n>=1000000) return (n/1000000).toFixed(n%1000000===0?0:1).replace(/\.0$/,'')+'M';
        if(n>=100000) return (n/1000).toFixed(n%1000===0?0:1).replace(/\.0$/,'')+'K';
        return n.toLocaleString();
    }
    let counted=false;
    const statsEl=document.querySelector('.stats');
    if(statsEl){
        new IntersectionObserver(entries=>{entries.forEach(e=>{if(e.isIntersecting&&!counted){counted=true;document.querySelectorAll('.stat-num').forEach(c=>{const t=+c.dataset.t,dur=1800,s=performance.now();const tick=now=>{const p=Math.min((now-s)/dur,1);const v=Math.round((1-Math.pow(1-p,4))*t);c.innerHTML=formatStatNum(v)+'<span class="plus"> +</span>';if(p<1)requestAnimationFrame(tick)};requestAnimationFrame(tick)})}})},{threshold:.3}).observe(statsEl);
    }

    // Drag scroll for all scrollable sections
    function initDragScroll(el){
        if(!el)return;
        let dn=false,sx,sl;
        el.addEventListener('mousedown',e=>{dn=true;el.style.cursor='grabbing';sx=e.pageX-el.offsetLeft;sl=el.scrollLeft});
        el.addEventListener('mouseleave',()=>{dn=false;el.style.cursor='grab'});
        el.addEventListener('mouseup',()=>{dn=false;el.style.cursor='grab'});
        el.addEventListener('mousemove',e=>{if(!dn)return;e.preventDefault();el.scrollLeft=sl-(e.pageX-el.offsetLeft-sx)*1.5});
        let tx=0,tl=0;
        el.addEventListener('touchstart',e=>{tx=e.touches[0].pageX;tl=el.scrollLeft},{passive:true});
        el.addEventListener('touchmove',e=>{el.scrollLeft=tl+(tx-e.touches[0].pageX)},{passive:true});
    }
    initDragScroll(document.querySelector('.svc-icons'));
    initDragScroll(document.querySelector('.sp-track'));
    initDragScroll(document.querySelector('.feat-grid'));
    initDragScroll(document.querySelector('.earn-grid'));
    initDragScroll(document.querySelector('.stats-grid'));
    initDragScroll(document.querySelector('.test-grid'));

    // sp-track: overflow check, dot pagination
    (function(){
        var track=document.querySelector('.sp-track');
        var dotsWrap=document.querySelector('.sp-dots');
        if(!track||!dotsWrap)return;

        function checkOverflow(){
            track.classList.toggle('is-overflowing',track.scrollWidth>track.clientWidth+2);
            buildDots();
        }

        function buildDots(){
            dotsWrap.innerHTML='';
            var cards=track.querySelectorAll('.sp-card');
            if(!track.classList.contains('is-overflowing')||cards.length<2)return;
            cards.forEach(function(_,i){
                var dot=document.createElement('button');
                dot.className='sp-dot';
                dot.setAttribute('type','button');
                dot.addEventListener('click',function(){
                    cards[i].scrollIntoView({behavior:'smooth',inline:'center',block:'nearest'});
                });
                dotsWrap.appendChild(dot);
            });
            updateActiveDot();
        }

        function updateActiveDot(){
            var cards=track.querySelectorAll('.sp-card');
            var dots=dotsWrap.querySelectorAll('.sp-dot');
            if(!dots.length)return;
            var trackRect=track.getBoundingClientRect();
            var center=trackRect.left+trackRect.width/2;
            var closest=0,minDist=Infinity;
            cards.forEach(function(card,i){
                var rect=card.getBoundingClientRect();
                var dist=Math.abs(rect.left+rect.width/2-center);
                if(dist<minDist){minDist=dist;closest=i}
            });
            dots.forEach(function(d,i){d.classList.toggle('active',i===closest)});
        }

        track.addEventListener('scroll',updateActiveDot);
        window.addEventListener('resize',checkOverflow);
        checkOverflow();
    })();

    // Slider arrow buttons + visibility (RTL compatible)
    const isRtl=document.documentElement.dir==='rtl';
    function getScrollPos(el){return isRtl?-el.scrollLeft:el.scrollLeft}
    function getMaxScroll(el){return el.scrollWidth-el.clientWidth}

    function updateSliderArrows(track){
        if(!track)return;
        const wrap=track.closest('.slider-wrap');
        if(!wrap)return;
        const prev=wrap.querySelector('.slider-prev');
        const next=wrap.querySelector('.slider-next');
        const overflows=track.scrollWidth>track.clientWidth+2;
        const pos=getScrollPos(track);
        const max=getMaxScroll(track);
        if(prev){
            if(overflows&&pos>2)prev.classList.add('visible');
            else prev.classList.remove('visible');
        }
        if(next){
            if(overflows&&pos<max-2)next.classList.add('visible');
            else next.classList.remove('visible');
        }
    }
    document.querySelectorAll('.slider-wrap').forEach(wrap=>{
        const prev=wrap.querySelector('.slider-prev');
        const next=wrap.querySelector('.slider-next');
        const target=prev?document.querySelector(prev.dataset.target):null;
        if(!target)return;
        updateSliderArrows(target);
        target.addEventListener('scroll',()=>updateSliderArrows(target));
        window.addEventListener('resize',()=>updateSliderArrows(target));
        if(prev)prev.addEventListener('click',()=>{
            const card=target.querySelector(':scope > *');const w=card?card.offsetWidth+14:300;
            target.scrollBy({left:isRtl?w:-w,behavior:'smooth'});
        });
        if(next)next.addEventListener('click',()=>{
            const card=target.querySelector(':scope > *');const w=card?card.offsetWidth+14:300;
            target.scrollBy({left:isRtl?-w:w,behavior:'smooth'});
        });
    });

    // Welcome modal
    @if (isset($new_user) && $new_user == true)
        $(document).ready(function(){
            $('#welcome-modal').modal('show');
            var url = new URL(window.location);
            url.searchParams.delete('new_user');
            window.history.replaceState({}, '', url.toString());
        });
    @endif
</script>
@endpush
